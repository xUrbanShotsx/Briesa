# Briesa — Backend Migration Guide (Step 1: Data Layer)

This adds a real Postgres database behind the app. The schema in
`prisma/schema.prisma` is derived 1:1 from `lib/mock-data.ts`, and
`prisma/seed.ts` loads your existing mock records into it — so the app looks
identical after migration, but every page reads live data.

## What was added

```
prisma/schema.prisma      Full multi-tenant schema (30+ models)
prisma/seed.ts            Seeds the DB from lib/mock-data.ts
lib/db.ts                 Prisma client singleton
lib/tenant.ts             Org-scoping helper (swap in real auth at step 2)
app/actions/workers.ts    Canonical CRUD pattern (org scope + audit log)
app/actions/swms.ts       SWMS with revision + signature audit trail
app/actions/dashboard.ts  Live KPI aggregations replacing kpiMetrics
```

## 1. Set up a database

Fastest options (both have AWS Sydney regions, which matters for AU clients):

- **Supabase** — supabase.com → New project → region `ap-southeast-2` → copy
  the connection string (Settings → Database → Connection string → URI).
- **Neon** — neon.tech → New project → region `ap-southeast-2`.

Create `.env` in the repo root:

```
DATABASE_URL="postgresql://USER:PASSWORD@HOST:5432/postgres"
```

Add `.env` to `.gitignore` (already done if you applied the package changes).

## 2. Install and migrate

```bash
npm install @prisma/client
npm install -D prisma tsx

npx prisma migrate dev --name init   # creates tables
npm run db:seed                      # loads your mock data
npx prisma studio                    # browse the data in a GUI
```

`package.json` scripts to add (already added if you took the updated file):

```json
"scripts": {
  "db:migrate": "prisma migrate dev",
  "db:seed": "tsx prisma/seed.ts",
  "db:studio": "prisma studio"
},
"prisma": { "seed": "tsx prisma/seed.ts" }
```

## 3. Migrate pages off mock data — the pattern

Your pages are currently `'use client'` components importing from
`lib/mock-data`. The cleanest migration per page:

**Before** (`app/dashboard/swms/page.tsx`):

```tsx
'use client'
import { swmsList as initialSwms } from '@/lib/mock-data'
export default function SwmsPage() {
  const [swms, setSwms] = useState(initialSwms)
  ...
}
```

**After** — split into a server page + client view:

```tsx
// app/dashboard/swms/page.tsx  (server component — no 'use client')
import { getSwmsList } from '@/app/actions/swms'
import SwmsView from './SwmsView'

export default async function SwmsPage() {
  const swms = await getSwmsList()
  return <SwmsView initialSwms={swms} />
}
```

```tsx
// app/dashboard/swms/SwmsView.tsx  ('use client' — your existing JSX, renamed)
'use client'
export default function SwmsView({ initialSwms }: { initialSwms: SwmsRow[] }) {
  const [swms, setSwms] = useState(initialSwms)
  // create/sign/revise buttons call the server actions directly:
  // await createSwms({...}); router.refresh()
}
```

The server actions already return data shaped like the mock objects
(lowercase statuses, site names instead of ids), so your existing JSX needs
minimal changes. Migrate in this order — each is independent:

1. Dashboard (`getDashboardData`, `getExpiringItems`) — biggest visual payoff
2. Workers + licences
3. SWMS (signature flow is the audit-critical one)
4. Incidents / hazards / corrective actions
5. Contractors + contractor portal
6. Everything else (permits, inspections, prestarts, toolbox, documents)

Delete entries from `lib/mock-data.ts` as each page migrates; when the file is
empty, the migration is done.

## 4. Rules baked into the actions (keep following them)

- **Always scope by org.** `findFirst({ where: { id, organisationId } })`,
  never `findUnique({ where: { id } })` — otherwise tenant A can read tenant
  B's records by guessing ids.
- **Every mutation appends an ActivityLog row.** It's the audit trail auditors
  ask for ("who changed this and when") and it powers the activity feed for
  free. Never update or delete log rows.
- **SWMS revisions are immutable.** `reviseSwms` supersedes and re-creates;
  signatures stay pinned to the revision that was signed.
- **KPI trends come from `ComplianceSnapshot`.** Add a daily cron (Vercel Cron
  hitting an API route, or Supabase scheduled function) that computes the
  day's scores and inserts one row per org. The dashboard trend chart then
  reads real history instead of the hardcoded `monthlyTrend`.

## 5. What deliberately waits for later steps

- Auth/sessions — `lib/tenant.ts` is the single swap point (step 2)
- File uploads for licences/insurances — add Supabase Storage or S3, store
  URLs in the `fileUrl` fields that already exist on the models (step 3)
- Email reminders for expiring items — `getExpiringItems()` is already the
  query a cron job needs; add Resend + a scheduled route (step 3)

## Note on the leftover files

`lib/agentbox.ts` and `types/realestate.ts` are from a different project and
nothing imports them — delete both when you commit this.
