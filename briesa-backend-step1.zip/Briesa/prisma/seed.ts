/**
 * Briesa seed script — populates the database from the existing mock data
 * so the app looks identical after the migration, but reads from Postgres.
 *
 * Run with: npm run db:seed
 */
import { PrismaClient, PermitType, PermitStatus, SwmsStatus, RiskRating } from '@prisma/client'
import {
  companyInfo, tasks, expiringItems, workers, sites, equipment,
  swmsList, trainingRecords, contractors, inspections, incidents,
  hazards, correctiveActions, documents, permits, prestartTemplates,
  toolboxTalks, activityFeed, kpiMetrics,
} from '../lib/mock-data'

const prisma = new PrismaClient()

const d = (s?: string | null) => (s ? new Date(s) : null)

const RISK: Record<string, RiskRating> = {
  low: 'LOW', medium: 'MEDIUM', high: 'HIGH', critical: 'CRITICAL',
}

const PERMIT_TYPE: Record<string, PermitType> = {
  'hot-work': 'HOT_WORK',
  'confined-space': 'CONFINED_SPACE',
  'working-at-heights': 'WORKING_AT_HEIGHTS',
  'electrical': 'ELECTRICAL',
  'excavation': 'EXCAVATION',
  'chem-handling': 'CHEM_HANDLING',
}

const PERMIT_STATUS: Record<string, PermitStatus> = {
  active: 'ACTIVE', pending: 'PENDING', expired: 'EXPIRED', closed: 'CLOSED',
}

async function main() {
  console.log('Seeding Briesa database…')

  // ── Organisation ──────────────────────────────────────────────────────────
  const org = await prisma.organisation.upsert({
    where: { id: 'org_acme' },
    update: {},
    create: {
      id: 'org_acme',
      name: companyInfo.name,
      industry: companyInfo.industry,
      plan: 'PROFESSIONAL',
      status: 'ACTIVE',
    },
  })

  // ── Demo users (passwords to be set up when auth lands in step 2) ────────
  await prisma.user.createMany({
    data: [
      { email: 'sarah@acme.example', name: 'Sarah Mitchell', role: 'ORG_OWNER', organisationId: org.id },
      { email: 'james@acme.example', name: 'James Chen', role: 'ORG_MANAGER', organisationId: org.id },
      { email: 'admin@briesa.example', name: 'Briesa Admin', role: 'ADMIN' },
    ],
    skipDuplicates: true,
  })

  // ── Sites ─────────────────────────────────────────────────────────────────
  const siteMap = new Map<string, string>() // mock name → db id
  for (const s of sites) {
    const row = await prisma.site.create({
      data: {
        organisationId: org.id,
        name: s.name,
        address: s.address,
        projectNumber: s.projectNumber,
        projectType: s.projectType,
        projectValue: s.projectValue,
        supervisor: s.supervisor,
        whsCoordinator: s.whsCoordinator,
        startDate: d(s.startDate),
        endDate: d(s.endDate),
        status: 'ACTIVE',
        hasWhsmp: s.hasWhsmp,
        currentOccupancy: s.currentOccupancy,
      },
    })
    siteMap.set(s.name, row.id)
  }
  // Mock data sometimes uses short site labels ("Site A") — map those too.
  for (const [name, id] of Array.from(siteMap)) {
    const short = name.split('–')[0]?.trim()
    if (short && !siteMap.has(short)) siteMap.set(short, id)
  }
  const siteId = (label?: string | null) => {
    if (!label) return null
    if (siteMap.has(label)) return siteMap.get(label)!
    for (const [name, id] of Array.from(siteMap)) {
      if (label.startsWith(name) || name.startsWith(label.split('—')[0].trim())) return id
    }
    return null
  }

  // ── Workers + licences ────────────────────────────────────────────────────
  const workerMap = new Map<string, string>()
  for (const w of workers) {
    const row = await prisma.worker.create({
      data: {
        organisationId: org.id,
        name: w.name,
        role: w.role,
        department: w.department,
        employmentType: w.employmentType === 'permanent' ? 'PERMANENT' : 'CASUAL',
        status: w.status === 'active' ? 'ACTIVE' : 'INACTIVE',
        approvalStatus: w.approvalStatus === 'approved' ? 'APPROVED' : 'PENDING',
        whiteCard: w.whiteCard,
        inductionComplete: w.inductionStatus === 'complete',
        lastOnSite: d(w.lastOnSite),
        licences: {
          create: (w.licences ?? []).map((l: any) => ({
            type: l.type,
            expiry: d(l.expiry),
          })),
        },
      },
    })
    workerMap.set(w.name, row.id)
  }

  // ── Training courses + records ────────────────────────────────────────────
  const courseMap = new Map<string, string>()
  for (const t of trainingRecords) {
    if (!courseMap.has(t.course)) {
      const c = await prisma.trainingCourse.create({
        data: { organisationId: org.id, name: t.course, category: 'SAFETY', frequency: 'ANNUAL' },
      })
      courseMap.set(t.course, c.id)
    }
    let workerId = workerMap.get(t.staffName)
    if (!workerId) {
      const w = await prisma.worker.create({
        data: { organisationId: org.id, name: t.staffName },
      })
      workerId = w.id
      workerMap.set(t.staffName, w.id)
    }
    await prisma.trainingRecord.create({
      data: {
        organisationId: org.id,
        workerId,
        courseId: courseMap.get(t.course)!,
        completedDate: d(t.completedDate),
        expiryDate: d(t.expiryDate),
        completion: t.completion,
      },
    })
  }

  // ── Equipment ─────────────────────────────────────────────────────────────
  for (const e of equipment) {
    await prisma.equipment.create({
      data: {
        organisationId: org.id,
        assetId: e.assetId,
        name: e.name,
        category: e.category,
        make: e.make,
        model: e.model,
        year: e.year,
        serialNumber: e.serialNumber,
        registrationNumber: e.registrationNumber,
        siteId: siteId(e.siteLocation),
        requiredLicence: e.requiredLicence,
        status: e.status === 'active' ? 'ACTIVE' : 'UNDER_SERVICE',
        lastServiceDate: d(e.lastServiceDate),
        nextServiceDate: d(e.nextServiceDate),
        serviceIntervalKm: e.serviceIntervalKm,
      },
    })
  }

  // ── Contractors ───────────────────────────────────────────────────────────
  for (const c of contractors) {
    await prisma.contractor.create({
      data: {
        organisationId: org.id,
        company: c.company,
        contactName: c.contact,
        phone: c.phone,
        industry: c.industry,
        preQualStatus:
          c.preQualStatus === 'approved' ? 'APPROVED'
          : c.preQualStatus === 'suspended' ? 'SUSPENDED' : 'PENDING',
        complianceStatus:
          c.status === 'compliant' ? 'COMPLIANT'
          : c.status === 'expiring' ? 'EXPIRING' : 'NON_COMPLIANT',
        workerCount: c.workers,
        documents: {
          create: [
            {
              name: 'Public Liability Insurance',
              type: 'insurance',
              status: c.status === 'non-compliant' ? 'EXPIRED' : 'CURRENT',
              expiryDate: d(c.insuranceExpiry),
            },
          ],
        },
      },
    })
  }

  // ── Permits ───────────────────────────────────────────────────────────────
  const permitMap = new Map<string, string>()
  for (const p of permits) {
    const row = await prisma.permit.create({
      data: {
        organisationId: org.id,
        permitNumber: p.id,
        type: PERMIT_TYPE[p.type],
        status: PERMIT_STATUS[p.status],
        siteId: siteId(p.site),
        issuedTo: p.requestedBy,
        issuedBy: p.approvedBy,
        validFrom: d(p.startDate),
        validTo: d(p.endDate),
        conditions: p.description,
      },
    })
    permitMap.set(p.id, row.id)
  }

  // ── SWMS (+ signatures up to signedCount) ─────────────────────────────────
  const allWorkerIds = Array.from(workerMap.values())
  for (const s of swmsList) {
    const status: SwmsStatus =
      s.status === 'active' ? 'ACTIVE' : s.status === 'draft' ? 'DRAFT' : 'SUPERSEDED'
    await prisma.swms.create({
      data: {
        organisationId: org.id,
        title: s.title,
        siteId: siteId(s.site),
        revision: s.revision,
        status,
        riskRating: RISK[s.riskRating],
        createdBy: s.createdBy,
        createdAt: new Date(s.createdDate),
        permitId: s.linkedPermit ? permitMap.get(s.linkedPermit) ?? null : null,
        signatures: {
          create: allWorkerIds.slice(0, Math.min(s.signedCount, allWorkerIds.length)).map(wid => ({
            workerId: wid,
            revision: s.revision,
          })),
        },
      },
    })
  }

  // ── Inspections ───────────────────────────────────────────────────────────
  for (const i of inspections) {
    await prisma.inspection.create({
      data: {
        organisationId: org.id,
        formType: i.formType,
        siteId: siteId(i.site),
        inspector: i.inspector,
        scheduledDate: d(i.date),
        completedDate: i.status === 'completed' ? d(i.date) : null,
        status:
          i.status === 'completed' ? 'COMPLETED'
          : i.status === 'in-progress' ? 'IN_PROGRESS' : 'SCHEDULED',
        score: i.score || null,
      },
    })
  }

  // ── Incidents → corrective actions ────────────────────────────────────────
  const incidentMap = new Map<string, string>()
  for (const inc of incidents) {
    const row = await prisma.incident.create({
      data: {
        organisationId: org.id,
        reference: inc.id,
        type: inc.type,
        severity:
          inc.severity === 'near-miss' ? 'NEAR_MISS'
          : inc.severity === 'minor' ? 'MINOR'
          : inc.severity === 'major' ? 'MAJOR' : 'CRITICAL',
        status:
          inc.status === 'closed' ? 'CLOSED'
          : inc.status === 'under-review' ? 'UNDER_REVIEW' : 'OPEN',
        occurredAt: new Date(inc.date),
        siteId: siteId(inc.location),
        reportedBy: inc.reportedBy,
      },
    })
    incidentMap.set(inc.id, row.id)
  }

  for (const ca of correctiveActions) {
    await prisma.correctiveAction.create({
      data: {
        organisationId: org.id,
        reference: ca.id,
        action: ca.action,
        incidentId: ca.relatedIncident ? incidentMap.get(ca.relatedIncident) ?? null : null,
        assignedTo: ca.assignedTo,
        dueDate: d(ca.dueDate),
        priority: ca.priority.toUpperCase() as any,
        status:
          ca.status === 'completed' ? 'COMPLETED'
          : ca.status === 'in-progress' ? 'IN_PROGRESS'
          : ca.status === 'overdue' ? 'OVERDUE' : 'OPEN',
      },
    })
  }

  // ── Hazards ───────────────────────────────────────────────────────────────
  for (const h of hazards) {
    await prisma.hazard.create({
      data: {
        organisationId: org.id,
        reference: h.id,
        description: h.description,
        category: h.category,
        siteId: siteId(h.site),
        likelihood: h.likelihood,
        consequence: h.consequence,
        riskRating: RISK[h.riskRating],
        control: h.control,
        raisedBy: h.raisedBy,
        raisedDate: d(h.raisedDate),
        assignedTo: h.assignedTo,
        status:
          h.status === 'closed' ? 'CLOSED'
          : h.status === 'in-progress' ? 'IN_PROGRESS' : 'OPEN',
      },
    })
  }

  // ── Documents (merge expiring items that are documents/insurances) ───────
  for (const doc of documents) {
    await prisma.document.create({
      data: {
        organisationId: org.id,
        name: doc.name,
        category: doc.category.toUpperCase() as any,
        version: doc.version,
        fileType: doc.fileType,
        updatedAt: new Date(doc.lastUpdated),
      },
    })
  }
  for (const item of expiringItems) {
    if (item.type === 'insurance' || item.type === 'document') {
      await prisma.document.create({
        data: {
          organisationId: org.id,
          name: item.name,
          category: item.type === 'insurance' ? 'INSURANCE' : 'OTHER',
          owner: item.owner,
          expiryDate: d(item.expiryDate),
        },
      })
    }
  }

  // ── Tasks ─────────────────────────────────────────────────────────────────
  for (const t of tasks) {
    await prisma.task.create({
      data: {
        organisationId: org.id,
        title: t.title,
        category: t.category,
        assignedTo: t.assignedTo,
        dueDate: d(t.dueDate),
        priority: t.priority.toUpperCase() as any,
        status:
          t.status === 'due-today' ? 'DUE_TODAY'
          : t.status === 'overdue' ? 'OVERDUE' : 'UPCOMING',
      },
    })
  }

  // ── Prestart templates & toolbox talks ────────────────────────────────────
  for (const pt of prestartTemplates) {
    await prisma.prestartTemplate.create({
      data: {
        organisationId: org.id,
        name: pt.name,
        equipmentCategory: pt.trade,
        items: pt.items.map((q, idx) => ({ id: `item-${idx + 1}`, question: q })),
      },
    })
  }
  for (const tb of toolboxTalks) {
    await prisma.toolboxTalk.create({
      data: {
        organisationId: org.id,
        topic: tb.topic,
        presenter: tb.presenter,
        siteId: siteId(tb.site),
        heldAt: d(tb.date),
      },
    })
  }

  // ── Activity log + first KPI snapshot ─────────────────────────────────────
  for (const a of activityFeed) {
    await prisma.activityLog.create({
      data: {
        organisationId: org.id,
        actorName: a.user,
        action: `${a.type}.event`,
        entityType: a.type,
        detail: `${a.action}: ${a.detail}`,
      },
    })
  }

  await prisma.complianceSnapshot.create({
    data: {
      organisationId: org.id,
      date: new Date(new Date().toDateString()),
      complianceScore: companyInfo.complianceScore,
      auditReadiness: companyInfo.auditReadiness,
      areaScores: Object.fromEntries(companyInfo.areas.map(a => [a.name, a.score])),
      ltifr: kpiMetrics.ltifr,
      trifr: kpiMetrics.trifr,
      mtifr: kpiMetrics.mtifr,
      nearMissFrequency: kpiMetrics.nearMissFrequency,
      daysLostToInjury: kpiMetrics.daysLostToInjury,
      metrics: {
        trainingCompletionRate: kpiMetrics.trainingCompletionRate,
        contractorsFullyQualified: kpiMetrics.contractorsFullyQualified,
        workersWithCurrentLicences: kpiMetrics.workersWithCurrentLicences,
      },
    },
  })

  console.log('Seed complete ✅')
}

main()
  .catch(e => { console.error(e); process.exit(1) })
  .finally(() => prisma.$disconnect())
