/**
 * Tenant scoping helper.
 *
 * Every query in the app MUST be scoped to an organisation. Until real auth
 * lands (step 2), this returns the seeded demo org. When you add Auth.js /
 * Supabase Auth, replace the body with a session lookup — every server action
 * already calls this, so nothing else changes.
 */
export async function getCurrentOrgId(): Promise<string> {
  // TODO (step 2): derive from session, e.g.
  // const session = await auth()
  // if (!session?.user?.organisationId) throw new Error('Unauthorised')
  // return session.user.organisationId
  return 'org_acme'
}

export async function getCurrentActor(): Promise<{ userId: string | null; name: string }> {
  // TODO (step 2): derive from session
  return { userId: null, name: 'Demo User' }
}
