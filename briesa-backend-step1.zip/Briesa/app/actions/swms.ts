'use server'

import { revalidatePath } from 'next/cache'
import { db } from '@/lib/db'
import { getCurrentOrgId, getCurrentActor } from '@/lib/tenant'

export async function getSwmsList() {
  const orgId = await getCurrentOrgId()
  const rows = await db.swms.findMany({
    where: { organisationId: orgId },
    include: {
      site: { select: { name: true } },
      permit: { select: { permitNumber: true } },
      _count: { select: { signatures: true } },
    },
    orderBy: { updatedAt: 'desc' },
  })
  // Shape matches what the SWMS page already renders.
  return rows.map(s => ({
    id: s.id,
    title: s.title,
    site: s.site?.name ?? '—',
    revision: s.revision,
    createdBy: s.createdBy ?? '—',
    createdDate: s.createdAt.toISOString(),
    status: s.status.toLowerCase() as 'active' | 'draft' | 'superseded',
    signedCount: s._count.signatures,
    linkedPermit: s.permit?.permitNumber ?? '',
    riskRating: s.riskRating.toLowerCase() as 'critical' | 'high' | 'medium' | 'low',
    highRiskActivities: s.highRiskActivities,
    reviewDate: s.reviewDate?.toISOString(),
  }))
}

export async function createSwms(input: {
  title: string
  siteId?: string
  riskRating?: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'
  highRiskActivities?: string[]
  content?: unknown
}) {
  const orgId = await getCurrentOrgId()
  const actor = await getCurrentActor()

  const swms = await db.swms.create({
    data: {
      organisationId: orgId,
      title: input.title,
      siteId: input.siteId,
      riskRating: input.riskRating ?? 'MEDIUM',
      highRiskActivities: input.highRiskActivities ?? [],
      content: input.content as any,
      createdBy: actor.name,
      status: 'DRAFT',
    },
  })

  await db.activityLog.create({
    data: {
      organisationId: orgId, userId: actor.userId, actorName: actor.name,
      action: 'swms.created', entityType: 'Swms', entityId: swms.id,
      detail: `SWMS drafted: ${swms.title}`,
    },
  })

  revalidatePath('/dashboard/swms')
  return swms
}

/**
 * Revising a SWMS supersedes the old record and creates a new revision.
 * Old signatures stay attached to the old revision — auditors can always
 * answer "who had signed v1.0 when the incident happened?"
 */
export async function reviseSwms(swmsId: string, changes: { content?: unknown; title?: string }) {
  const orgId = await getCurrentOrgId()
  const actor = await getCurrentActor()

  const current = await db.swms.findFirst({ where: { id: swmsId, organisationId: orgId } })
  if (!current) throw new Error('SWMS not found')

  const [major, minor] = current.revision.replace('v', '').split('.').map(Number)
  const nextRevision = `v${major}.${(minor ?? 0) + 1}`

  const [, next] = await db.$transaction([
    db.swms.update({ where: { id: current.id }, data: { status: 'SUPERSEDED' } }),
    db.swms.create({
      data: {
        organisationId: orgId,
        title: changes.title ?? current.title,
        siteId: current.siteId,
        revision: nextRevision,
        status: 'ACTIVE',
        riskRating: current.riskRating,
        highRiskActivities: current.highRiskActivities,
        content: (changes.content ?? current.content) as any,
        createdBy: actor.name,
        permitId: current.permitId,
      },
    }),
    db.activityLog.create({
      data: {
        organisationId: orgId, userId: actor.userId, actorName: actor.name,
        action: 'swms.revised', entityType: 'Swms', entityId: current.id,
        detail: `${current.title} revised ${current.revision} → ${nextRevision}`,
      },
    }),
  ])

  revalidatePath('/dashboard/swms')
  return next
}

export async function signSwms(swmsId: string, workerId: string) {
  const orgId = await getCurrentOrgId()

  const swms = await db.swms.findFirst({ where: { id: swmsId, organisationId: orgId } })
  if (!swms) throw new Error('SWMS not found')
  if (swms.status !== 'ACTIVE') throw new Error('Only active SWMS can be signed')

  const worker = await db.worker.findFirst({ where: { id: workerId, organisationId: orgId } })
  if (!worker) throw new Error('Worker not found')

  const signature = await db.swmsSignature.upsert({
    where: { swmsId_workerId_revision: { swmsId, workerId, revision: swms.revision } },
    update: {},
    create: { swmsId, workerId, revision: swms.revision },
  })

  await db.activityLog.create({
    data: {
      organisationId: orgId, actorName: worker.name,
      action: 'swms.signed', entityType: 'Swms', entityId: swmsId,
      detail: `${worker.name} signed ${swms.title} (${swms.revision})`,
    },
  })

  revalidatePath('/dashboard/swms')
  return signature
}
