'use server'

/**
 * Workers data layer — the canonical pattern for replacing mock-data imports.
 *
 * Pattern for every entity:
 *   1. scope to org via getCurrentOrgId()
 *   2. read/write through Prisma
 *   3. append to ActivityLog on every mutation (immutable audit trail)
 *   4. revalidatePath so the UI refreshes
 */

import { revalidatePath } from 'next/cache'
import { db } from '@/lib/db'
import { getCurrentOrgId, getCurrentActor } from '@/lib/tenant'

export async function getWorkers() {
  const orgId = await getCurrentOrgId()
  return db.worker.findMany({
    where: { organisationId: orgId },
    include: { licences: true, trainingRecords: { include: { course: true } } },
    orderBy: { name: 'asc' },
  })
}

export async function getWorker(id: string) {
  const orgId = await getCurrentOrgId()
  return db.worker.findFirst({
    // findFirst with org filter — never findUnique by id alone, or one tenant
    // could read another tenant's record by guessing ids.
    where: { id, organisationId: orgId },
    include: { licences: true, trainingRecords: { include: { course: true } } },
  })
}

export async function createWorker(input: {
  name: string
  role?: string
  department?: string
  employmentType?: 'PERMANENT' | 'CASUAL' | 'CONTRACT' | 'LABOUR_HIRE'
  whiteCard?: boolean
}) {
  const orgId = await getCurrentOrgId()
  const actor = await getCurrentActor()

  const worker = await db.worker.create({
    data: { organisationId: orgId, ...input },
  })

  await db.activityLog.create({
    data: {
      organisationId: orgId,
      userId: actor.userId,
      actorName: actor.name,
      action: 'worker.created',
      entityType: 'Worker',
      entityId: worker.id,
      detail: `Worker added: ${worker.name}`,
    },
  })

  revalidatePath('/dashboard/workers')
  return worker
}

export async function addLicence(workerId: string, input: { type: string; number?: string; expiry?: string }) {
  const orgId = await getCurrentOrgId()
  const actor = await getCurrentActor()

  // Verify the worker belongs to this org before touching child records.
  const worker = await db.worker.findFirst({ where: { id: workerId, organisationId: orgId } })
  if (!worker) throw new Error('Worker not found')

  const licence = await db.licence.create({
    data: {
      workerId,
      type: input.type,
      number: input.number,
      expiry: input.expiry ? new Date(input.expiry) : null,
    },
  })

  await db.activityLog.create({
    data: {
      organisationId: orgId,
      userId: actor.userId,
      actorName: actor.name,
      action: 'licence.added',
      entityType: 'Licence',
      entityId: licence.id,
      detail: `${input.type} added for ${worker.name}`,
    },
  })

  revalidatePath(`/dashboard/workers/${workerId}`)
  return licence
}

/** Licences/certs expiring within `days` — powers the dashboard expiring table. */
export async function getExpiringLicences(days = 30) {
  const orgId = await getCurrentOrgId()
  const horizon = new Date(Date.now() + days * 86_400_000)
  return db.licence.findMany({
    where: {
      worker: { organisationId: orgId },
      expiry: { not: null, lte: horizon },
    },
    include: { worker: { select: { id: true, name: true } } },
    orderBy: { expiry: 'asc' },
  })
}
