'use server'

import { db } from '@/lib/db'
import { getCurrentOrgId } from '@/lib/tenant'

/**
 * Replaces the hardcoded companyInfo / kpiMetrics / activityFeed objects.
 * Live counts are computed on demand; trend lines come from ComplianceSnapshot
 * rows written by a daily cron (see MIGRATION.md).
 */
export async function getDashboardData() {
  const orgId = await getCurrentOrgId()
  const now = new Date()
  const in30 = new Date(now.getTime() + 30 * 86_400_000)
  const startOfToday = new Date(now.toDateString())

  const [
    org,
    openIncidents,
    overdueTasks,
    dueTodayTasks,
    expiringLicences,
    expiringDocs,
    openHazards,
    openActions,
    activePermits,
    latestSnapshot,
    trend,
    activity,
  ] = await Promise.all([
    db.organisation.findUnique({ where: { id: orgId } }),
    db.incident.count({ where: { organisationId: orgId, status: { not: 'CLOSED' } } }),
    db.task.count({ where: { organisationId: orgId, status: 'OVERDUE' } }),
    db.task.count({
      where: {
        organisationId: orgId,
        status: { not: 'COMPLETED' },
        dueDate: { gte: startOfToday, lt: new Date(startOfToday.getTime() + 86_400_000) },
      },
    }),
    db.licence.count({
      where: { worker: { organisationId: orgId }, expiry: { not: null, lte: in30, gte: now } },
    }),
    db.document.count({
      where: { organisationId: orgId, expiryDate: { not: null, lte: in30, gte: now } },
    }),
    db.hazard.count({ where: { organisationId: orgId, status: { not: 'CLOSED' } } }),
    db.correctiveAction.count({ where: { organisationId: orgId, status: { in: ['OPEN', 'IN_PROGRESS', 'OVERDUE'] } } }),
    db.permit.count({ where: { organisationId: orgId, status: 'ACTIVE' } }),
    db.complianceSnapshot.findFirst({
      where: { organisationId: orgId },
      orderBy: { date: 'desc' },
    }),
    db.complianceSnapshot.findMany({
      where: { organisationId: orgId },
      orderBy: { date: 'asc' },
      take: 12,
      select: { date: true, complianceScore: true, ltifr: true },
    }),
    db.activityLog.findMany({
      where: { organisationId: orgId },
      orderBy: { createdAt: 'desc' },
      take: 8,
    }),
  ])

  return {
    companyName: org?.name ?? '',
    complianceScore: latestSnapshot?.complianceScore ?? null,
    auditReadiness: latestSnapshot?.auditReadiness ?? null,
    areaScores: (latestSnapshot?.areaScores as Record<string, number> | null) ?? {},
    counts: {
      openIncidents, overdueTasks, dueTodayTasks,
      expiringLicences, expiringDocs, openHazards,
      openActions, activePermits,
    },
    trend: trend.map(t => ({
      month: t.date.toLocaleString('en-AU', { month: 'short' }),
      score: t.complianceScore,
      ltifr: t.ltifr,
    })),
    activityFeed: activity.map(a => ({
      id: a.id,
      action: a.action,
      detail: a.detail ?? '',
      user: a.actorName ?? 'System',
      time: a.createdAt.toISOString(),
      type: a.entityType.toLowerCase(),
    })),
  }
}

/** Everything expiring in the next `days` days, across licences, training and documents. */
export async function getExpiringItems(days = 45) {
  const orgId = await getCurrentOrgId()
  const horizon = new Date(Date.now() + days * 86_400_000)

  const [licences, training, docs] = await Promise.all([
    db.licence.findMany({
      where: { worker: { organisationId: orgId }, expiry: { not: null, lte: horizon } },
      include: { worker: { select: { name: true } } },
    }),
    db.trainingRecord.findMany({
      where: { organisationId: orgId, expiryDate: { not: null, lte: horizon } },
      include: { worker: { select: { name: true } }, course: { select: { name: true } } },
    }),
    db.document.findMany({
      where: { organisationId: orgId, expiryDate: { not: null, lte: horizon } },
    }),
  ])

  const now = Date.now()
  const status = (d: Date): 'expired' | 'expiring-soon' =>
    d.getTime() < now ? 'expired' : 'expiring-soon'

  return [
    ...licences.map(l => ({
      id: l.id, name: `${l.type} – ${l.worker.name}`, type: 'licence' as const,
      owner: l.worker.name, expiryDate: l.expiry!.toISOString(), status: status(l.expiry!),
    })),
    ...training.map(t => ({
      id: t.id, name: `${t.course.name} – ${t.worker.name}`, type: 'certificate' as const,
      owner: t.worker.name, expiryDate: t.expiryDate!.toISOString(), status: status(t.expiryDate!),
    })),
    ...docs.map(dc => ({
      id: dc.id, name: dc.name,
      type: dc.category === 'INSURANCE' ? ('insurance' as const) : ('document' as const),
      owner: dc.owner ?? '—', expiryDate: dc.expiryDate!.toISOString(), status: status(dc.expiryDate!),
    })),
  ].sort((a, b) => a.expiryDate.localeCompare(b.expiryDate))
}
